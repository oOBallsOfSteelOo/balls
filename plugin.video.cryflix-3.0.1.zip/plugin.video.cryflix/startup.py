# -*- coding: utf-8 -*-

import traceback
import sys
import os

PACKAGE_PARENT = '..'
SCRIPT_DIR = os.path.dirname(os.path.realpath(os.path.join(os.getcwd(), os.path.expanduser(__file__))))
sys.path.append(os.path.normpath(os.path.join(SCRIPT_DIR, PACKAGE_PARENT)))

if __name__ == "__main__":
    output = None
    try:
        from plugin import __run, __output

        output = __output
        __run()

    except Exception as e:
        import xbmcgui

        xbmcgui.Dialog().ok("Entschuldigung :(",
                            "Leider wurde ein unerwarteter Fehler festgestellt.\nBitte erneut Probieren ansonsten das Plugin erneut [B]Installieren[/B]!")
        raise
