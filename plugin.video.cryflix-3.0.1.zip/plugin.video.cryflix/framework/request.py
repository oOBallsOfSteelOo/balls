from .common import unpickle_args

try:
    import urllib.parse as urllib_parse  #for python 3
except ImportError:
    import urlparse as urllib_parse


class Request(object):
    def __init__(self, url, handle):
        #: The entire request url.
        self.url = url

        #: The current request's handle, an integer.
        self.handle = int(handle)

        # urlparse doesn't like the 'plugin' scheme, so pass a protocol
        # relative url, e.g. //plugin.video.helloxbmc/path
        self.scheme, remainder = url.split(':', 1)
        parts = urllib_parse.urlparse(remainder)
        self.netloc, self.path, self.query_string = (parts[1], parts[2], parts[4])
        self.args = unpickle_args(urllib_parse.parse_qs(self.query_string))
